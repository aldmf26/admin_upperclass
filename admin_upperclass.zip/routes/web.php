<?php

use App\Http\Controllers\AboutController;
use App\Http\Controllers\BannerController;
use App\Http\Controllers\BestSellerController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\DistribusiController;
use App\Http\Controllers\KategoriController;
use App\Http\Controllers\LoginControler;
use App\Http\Controllers\LokasiController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\ProdukController;
use App\Http\Controllers\SatuanController;
use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/', [LoginControler::class, 'index'])->name('login');
Route::post('/aksiLogin', [LoginControler::class, 'aksiLogin'])->name('aksiLogin');
Route::get('/logout', [LoginControler::class, 'logout'])->name('logout');

Route::get('/user', [UserController::class, 'index'])->name('user');
Route::post('/tambahUser', [UserController::class, 'tambahUser'])->name('tambahUser');
Route::post('/ubahUser', [UserController::class, 'ubahUser'])->name('ubahUser');
Route::get('/hapusUser', [UserController::class, 'hapusUser'])->name('hapusUser');

Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');
// produk
Route::get('/produk', [ProdukController::class, 'index'])->name('produk');
Route::post('/tambahProduk', [ProdukController::class, 'tambahProduk'])->name('tambahProduk');
Route::post('/ubahProduk', [ProdukController::class, 'ubahProduk'])->name('ubahProduk');
Route::get('/hapusProduk', [ProdukController::class, 'hapusProduk'])->name('hapusProduk');
Route::post('/tbhDistribusi', [ProdukController::class, 'tbhDistribusi'])->name('tbhDistribusi');
Route::get('/uploadImages', [ProdukController::class, 'uploadImages'])->name('uploadImages');
Route::post('/importProduk', [ProdukController::class, 'importProduk'])->name('importProduk');
Route::get('/exportFormat', [ProdukController::class, 'exportFormat'])->name('exportFormat');
Route::get('/hapusLinkV', [ProdukController::class, 'hapusLinkV'])->name('hapusLinkV');
Route::get('/bestSeller', [ProdukController::class, 'bestSeller'])->name('bestSeller');
Route::get('/bestSellerInput', [ProdukController::class, 'bestSellerInput'])->name('bestSellerInput');
Route::post('/tbhKategoriProduk', [ProdukController::class, 'tbhKategoriProduk'])->name('tbhKategoriProduk');

// about
Route::get('/about', [AboutController::class, 'index'])->name('about');
Route::post('/tambahAbout', [AboutController::class, 'tambahAbout'])->name('tambahAbout');
Route::post('/ubahAbout', [AboutController::class, 'ubahAbout'])->name('ubahAbout');
Route::get('/hapusAbout', [AboutController::class, 'hapusAbout'])->name('hapusAbout');

// banner
Route::get('/banner', [BannerController::class, 'index'])->name('banner');
Route::post('/tambahBanner', [BannerController::class, 'tambahBanner'])->name('tambahBanner');
Route::post('/ubahBanner', [BannerController::class, 'ubahBanner'])->name('ubahBanner');
Route::get('/hapusBanner', [BannerController::class, 'hapusBanner'])->name('hapusBanner');

// lokasi
Route::get('/lokasi', [LokasiController::class, 'index'])->name('lokasi');
Route::post('/tambahLokasi', [LokasiController::class, 'tambahLokasi'])->name('tambahLokasi');
Route::post('/ubahLokasi', [LokasiController::class, 'ubahLokasi'])->name('ubahLokasi');
Route::get('/hapusLokasi', [LokasiController::class, 'hapusLokasi'])->name('hapusLokasi');

// kategori
Route::get('/kategori', [KategoriController::class, 'index'])->name('kategori');
Route::post('/tambahKategori', [KategoriController::class, 'tambahKategori'])->name('tambahKategori');
Route::post('/ubahKategori', [KategoriController::class, 'ubahKategori'])->name('ubahKategori');
Route::get('/hapusKategori', [KategoriController::class, 'hapusKategori'])->name('hapusKategori');

// satuan
Route::get('/satuan', [SatuanController::class, 'index'])->name('satuan');
Route::post('/tambahSatuan', [SatuanController::class, 'tambahSatuan'])->name('tambahSatuan');
Route::post('/ubahSatuan', [SatuanController::class, 'ubahSatuan'])->name('ubahSatuan');
Route::get('/hapusSatuan', [SatuanController::class, 'hapusSatuan'])->name('hapusSatuan');

// distribusi
Route::get('/distribusi', [DistribusiController::class, 'index'])->name('distribusi');
Route::post('/tambahDistribusi', [DistribusiController::class, 'tambahDistribusi'])->name('tambahDistribusi');
Route::post('/ubahDistribusi', [DistribusiController::class, 'ubahDistribusi'])->name('ubahDistribusi');
Route::get('/hapusDistribusi', [DistribusiController::class, 'hapusDistribusi'])->name('hapusDistribusi');
