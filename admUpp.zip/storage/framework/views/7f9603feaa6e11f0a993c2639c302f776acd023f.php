
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Katagori Product</h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active">Katagori Product</li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-9">
                    <div class="card">
                        <div class="card-header">
                            <a href="#" data-target="#tambah" data-toggle="modal" class="btn btn-md btn-primary"><i class="fa fa-plus"></i></a>
                        </div>
                        <div class="card-body">
                            <table id="example2" class="table table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th>NO</th>
                                        <th>LOKASI</th>
                                        <th>DESKRIPSI</th>
                                        <th>AKSI</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        $no = 1;
                                    ?>
                                    <?php $__currentLoopData = $footer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td width="10"><?php echo e($no++); ?></td>
                                            <td><?php echo e($k->nm_lokasi); ?></td>
                                            <td><?php echo e($k->deskripsi); ?></td>
                                            <td align="center">
                                                <a href="#" data-toggle="modal"
                                                    data-target="#edit<?php echo e($k->id_footer); ?>"
                                                    class="btn btn-warning btn-sm"><i class="fa fa-edit"></i></a>
                                                <a onclick="return confirm('Apakah ingin dihapus ?')"
                                                    href="<?php echo e(route('hapusKategori', ['id' => $k->id_footer])); ?>"
                                                    class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            </div>
        </div>
        <!--/. container-fluid -->
    </section>
    <!-- /.content -->
</div>

<form action="<?php echo e(route('tambahFooter')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <div class="modal fade" id="tambah" role="dialog"
        aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-md" role="document">
            <div class="modal-content ">
                <div class="modal-header btn-costume">
                    <h5 class="modal-title text-dark" id="exampleModalLabel">Tambah Footer Info</h5>
                    <button type="button" class="close text-dark" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-12">
                            <div class="form-group">
                                <label for=""></label>
                                <select name="id_lokasi" id="" class="form-control">
                                    <option value="">- Pilih Lokasi -</option>
                                    <?php $__currentLoopData = $lokasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($l->id_lokasi); ?>"><?php echo e($l->nm_lokasi); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="form-group">
                                <label for="">Deskripsi</label>
                                <textarea class="ckeditor" id="ckedtor" name="deskripsi"></textarea>
                            </div>
                        </div>    
                    </div>                 
                </div>
                <div class="modal-footer">

                    <button type="submit" class="btn btn-success">Save</button>
                </div>
            </div>
        </div>
    </div>
</form>


<?php $__currentLoopData = $footer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<form action="<?php echo e(route('ubahFooter')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <div class="modal fade" id="edit<?php echo e($f->id_footer); ?>" role="dialog"
        aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-md" role="document">
            <div class="modal-content ">
                <div class="modal-header btn-costume">
                    <h5 class="modal-title text-dark" id="exampleModalLabel">Ubah Footer Info</h5>
                    <button type="button" class="close text-dark" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-12">
                            <div class="form-group">
                                <input type="hidden" name="id_footer" value="<?php echo e($f->id_footer); ?>">
                                <label for=""></label>
                                <select name="id_lokasi" id="" class="form-control">
                                    <option value="">- Pilih Lokasi -</option>
                                    <?php $__currentLoopData = $lokasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php echo e($f->id_lokasi == $l->id_lokasi ? 'selected' : ''); ?> value="<?php echo e($l->id_lokasi); ?>"><?php echo e($l->nm_lokasi); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="form-group">
                                <label for="">Deskripsi</label>
                                <textarea class="ckeditor" id="ckedtor" name="deskripsi"><?php echo e($f->deskripsi); ?></textarea>
                            </div>
                        </div>                       
                        <?php
                            $sosmed = DB::table('tb_footer_sosmed')->where('id_footer', $f->id_footer)->get();
                        ?>
                        
                       
                            <div class="col-12">
                                <div class="form-group">
                                <label for="">Nama Sosmed</label>
                                <?php $__currentLoopData = $sosmed; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <input type="hidden" name="id_footer_sosmed[]" value="<?php echo e($s->id_fs); ?>">
                                <input class="form-control" type="text" value="<?php echo e($s->nm_sosmed); ?>" readonly>
                                <input class="form-control mb-3" type="text" value="<?php echo e($s->link); ?>" name="link[]">
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            </div>
                    
                         
                    </div>                 
                </div>
                <div class="modal-footer">

                    <button type="submit" class="btn btn-success">Save</button>
                </div>
            </div>
        </div>
    </div>
</form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        <?php if(Session::get('sukses')) { ?>
        Swal.fire({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000,
            icon: 'success',
            title: "<?php echo e(Session::get('sukses')); ?>"
        });
        <?php }elseif(Session::get('error')) { ?>
        Swal.fire({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000,
            icon: 'error',
            title: "<?php echo e(Session::get('error')); ?>"
        });
        <?php } ?>
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\admin_upperclass\resources\views/footer/footer.blade.php ENDPATH**/ ?>