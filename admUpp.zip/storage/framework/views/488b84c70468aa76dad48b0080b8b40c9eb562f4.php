
<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">Best Seller Product</h1>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item active">Best Seller Product</li>
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->

        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <table id="example2" class="table table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th>NO</th>
                                            <th>FOTO</th>
                                            <th>LOKASI</th>
                                            <th>KATEGORI</th>
                                            <th>NAMA PRODUK</th>
                                            <th>BEST SELLER</th>
                                            <th>TOP RATE</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                            $no = 1;
                                        ?>
                                        <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td width="10" align="center"><?php echo e($no++); ?></td>
                                                <td align="center">
                                                    <img width="30%"
                                                        src="<?php echo e(asset('assets')); ?>/uploads/<?php echo e($k->foto); ?>" alt="">
                                                    <a href="#" data-toggle="modal" data-target="#edit<?php echo e($k->id_produk); ?>"
                                                        class="btn btn-info btn-sm"><i class="fa fa-eye"></i></a>
                                                </td>
                                                <td><?php echo e($k->nm_lokasi); ?></td>
                                                <td><?php echo e($k->nm_kategori); ?></td>
                                                <td><?php echo e($k->nm_produk); ?></td>
                                                <td>
                                                    
                                                    <?php if($k->best_seller == ''){ ?>
                                                    <a class="btn btn-sm btn-info btnInput" cek="best_seller" value="ON"
                                                        id_produk="<?php echo e($k->id_produk); ?>">OFF</a>
                                                    <?php }else{ ?>
                                                    <a class="btn btn-sm btn-primary btnDelete" cek="best_seller" value=""
                                                        id_produk="<?php echo e($k->id_produk); ?>">ON</a>
                                                    <?php } ?>
                                                </td>
                                                <td>
                                                    
                                                    <?php if($k->top_rate == ''){ ?>
                                                    <a class="btn btn-sm btn-info btnInput" cek="top_rate" value="ON"
                                                        id_produk="<?php echo e($k->id_produk); ?>">OFF</a>
                                                    <?php }else{ ?>
                                                    <a class="btn btn-sm btn-primary btnDelete" cek="top_rate" value=""
                                                        id_produk="<?php echo e($k->id_produk); ?>">ON</a>
                                                    <?php } ?>
                                                </td>
                                            </tr>
                                            <div class="modal fade" id="edit<?php echo e($k->id_produk); ?>" role="dialog"
                                                aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                <div class="modal-dialog modal-lg" role="document">
                                                    <div class="modal-content ">
                                                        <div class="modal-header btn-costume">
                                                            <h5 class="modal-title text-dark" id="exampleModalLabel">View
                                                                Foto</h5>
                                                            <button type="button" class="close text-dark"
                                                                data-dismiss="modal" aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <input type="hidden" name="id_banner"
                                                                value="<?php echo e($k->id_produk); ?>">
                                                            <div class="row justify-content-center">
                                                                <div class="col-12">
                                                                    <img width="100%"
                                                                        src="<?php echo e(asset('assets')); ?>/uploads/<?php echo e($k->foto); ?>"
                                                                        alt="">
                                                                </div>
                                                            </div>

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
            <!--/. container-fluid -->
        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->




    <!-- Control Sidebar -->
    <aside class="control-sidebar control-sidebar-dark">
        <!-- Control sidebar content goes here -->
    </aside>
    <!-- /.control-sidebar -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function() {
            $(document).on('click', '.btnInput', function() {
                var id_produk = $(this).attr('id_produk')
                var value = $(this).attr('value')
                var cek = $(this).attr('cek')

                $.ajax({
                    type: "GET",
                    url: "<?php echo e(route('bestSellerInput')); ?>?id_produk=" + id_produk + "&v=" +
                        value + "&cek=" + cek,
                    success: function(response) {
                        location.reload();
                        Swal.fire({
                            toast: true,
                            position: 'top-end',
                            showConfirmButton: false,
                            timer: 3000,
                            icon: 'success',
                            title: "Produk telah masuk best seller"
                        });
                    }
                });
            })
            $(document).on('click', '.btnDelete', function() {
                var id_produk = $(this).attr('id_produk')
                var value = $(this).attr('value')
                var cek = $(this).attr('cek')

                $.ajax({
                    type: "GET",
                    url: "<?php echo e(route('bestSellerInput')); ?>?id_produk=" + id_produk + "&v=" +
                        value + "&cek=" + cek,
                    success: function(response) {
                        location.reload();
                        Swal.fire({
                            toast: true,
                            position: 'top-end',
                            showConfirmButton: false,
                            timer: 3000,
                            icon: 'error',
                            title: "Produk dihapus dari best seller"
                        });
                    }
                });

            })


        })
        // <?php if(Session::get('sukses')) { ?>

        // <?php }elseif(Session::get('error')) { ?>

        // <?php } ?>
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\admin_upperclass\resources\views/bestSeller/bestSeller.blade.php ENDPATH**/ ?>