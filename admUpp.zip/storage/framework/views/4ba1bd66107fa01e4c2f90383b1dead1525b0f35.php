
<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">Transaksi Masuk</h1>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item active">Transaksi Masuk</li>
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->

        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            
                            <div class="card-body">
                                <table id="example2" class="table table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th class="text-center">#</th>
                                            <th width='100' class="text-center">NO ORDER</th>
                                            <th>NAMA</th>
                                            <th>EMAIL</th>
                                            <th>NO HP</th>
                                            <th class="text-center">TRANSAKSI TOTAL</th>
                                            <th>STATUS</th>
                                            <th>AKSI</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                            $no = 1;
                                        ?>
                                        <?php $__currentLoopData = $transaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td align="center"><?php echo e($no++); ?></td>
                                            <td align="center"><?php echo e(Str::substr($t->no_order,14)); ?></td>
                                            <td><?php echo e($t->name); ?></td>
                                            <td><?php echo e($t->email); ?></td>
                                            <td><?php echo e($t->nohp); ?></td>
                                            <td align="right"><?php echo e(number_format($t->totTransaksi,0)); ?></td>
                                            <td align="center">
                                                <?php if($t->status == 'PENDING'): ?>
                                                    <span class="badge badge-info">PENDING</span>
                                                <?php elseif($t->status == 'SUCCESS'): ?>
                                                    <span class="badge badge-success">SUCCESS</span>
                                                <?php elseif($t->status == 'FAILED'): ?>
                                                    <span class="badge badge-warning">FAILED</span>    
                                                <?php endif; ?>
                                            </td>
                                            
                                            <td align="center">
                                                <a
                                                    href="#" data-toggle="modal" data-target="#detail<?php echo e($t->id_transaksi); ?>"
                                                    class="btn btn-info btn-sm"><i class="fa fa-eye"></i></a>
                                                
                                            </td>
                                        </tr>                                                                                 
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
            <!--/. container-fluid -->
        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
    <?php $__currentLoopData = $transaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="modal fade" id="detail<?php echo e($t->id_transaksi); ?>" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content ">
                <div class="modal-header btn-costume">
                    <h5 class="modal-title text-dark" id="exampleModalLabel">Edit Kategori</h5>
                    <button type="button" class="close text-dark" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                
                <div class="modal-body">
                    <table class="table">
                        <tr>
                            <th width="30%">Nama</th>
                            <td><?php echo e($t->name); ?></td>
                        </tr>
                        <tr>
                            <th>Email</th>
                            <td><?php echo e($t->email); ?></td>
                        </tr>
                        <tr>
                            <th>No Hp</th>
                            <td><?php echo e($t->nohp); ?></td>
                        </tr>
                        <tr>
                            <th>Alamat</th>
                            <td><?php echo e($t->alamat); ?></td>
                        </tr>
                        <tr>
                            <th>Shipping</th>
                            <td><?php echo e(number_format($t->shipping,0)); ?></td>
                        </tr>
                        <tr>
                            <th>Voucher</th>
                            <td><?php echo e($t->voucher == '' ? 'tidak ada' : number_format($t->voucher,0)); ?></td>
                        </tr>
                        <tr>
                            <th>Total Transaksi</th>
                            <td><?php echo e(number_format($t->totTransaksi,0)); ?></td>
                        </tr>
                        <tr>
                            <th>Status Transaksi</th>
                            <td><?php echo e($t->status); ?></td>
                        </tr>
                        <tr>
                            <th>Pembelian Produk</th>
                            <td>
                                <table width="100%">
                                    <tr>
                                        <th>Nama</th>
                                        <th>Qty</th>
                                        <th>Harga</th>
                                    </tr>
                                    <?php
                                        $produk = DB::table('tb_produk')->join('tb_harga', 'tb_harga.id_harga', '=', 'tb_produk.id_produk')->join('tb_order', 'tb_order.id_harga', '=','tb_harga.id_harga')->where('tb_order.no_order', $t->no_order)->get();
                                    ?>
                                    <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($p->nm_produk); ?></td>
                                            <td><?php echo e($p->qty); ?></td>
                                            <td><?php echo e($p->harga); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </table>
                            </td>
                        </tr>
                    </table>
                    <div class="row">
                        <div class="col-4">
                            <a href="<?php echo e(route('setStatus', ['id' => $t->id_transaksi, 'status' => 'SUCCESS'])); ?>" class="btn btn-success btn-sm btn-block"><i class="fa fa-check"></i> Set Sukses</a>
                        </div>
                        <div class="col-4">
                            <a href="<?php echo e(route('setStatus', ['id' => $t->id_transaksi, 'status' => 'FAILED'])); ?>" class="btn btn-warning btn-sm btn-block"><i class="fa fa-times"></i> Set Gagal</a>
                        </div>
                        <div class="col-4">
                            <a href="<?php echo e(route('setStatus', ['id' => $t->id_transaksi, 'status' => 'PENDING'])); ?>" class="btn btn-info btn-sm btn-block"><i class="fa fa-spinner"></i> Set Pending</a>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">

                    <button type="submit" class="btn btn-success">Save</button>
                </div>
            </div>
        </div>
    </div>
        
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <!-- Control Sidebar -->
    <aside class="control-sidebar control-sidebar-dark">
        <!-- Control sidebar content goes here -->
    </aside>
    <!-- /.control-sidebar -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        <?php if(Session::get('sukses')) { ?>
        Swal.fire({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000,
            icon: 'success',
            title: "<?php echo e(Session::get('sukses')); ?>"
        });
        <?php }elseif(Session::get('error')) { ?>
        Swal.fire({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000,
            icon: 'error',
            title: "<?php echo e(Session::get('error')); ?>"
        });
        <?php } ?>
    </script>

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\admin_upperclass\resources\views/transaksi/transaksi.blade.php ENDPATH**/ ?>