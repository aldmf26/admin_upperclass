
<?php $__env->startSection('content'); ?>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">Distribusi</h1>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item active">Distribusi</li>
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->

        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <table id="example2" class="table table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th align='center'>#</th>
                                            <th>KODE</th>
                                            <th>JUMLAH</th>
                                            <th>KETERANGAN</th>
                                            <th>EXPIRED</th>
                                            <th>STATUS</th>
                                            <th>AKSI</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                            $no = 1;
                                        ?>
                                        <tr>
                                            <form action="<?php echo e(route('tambahVoucher')); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <td></td>
                                                <td></td>
                                                <td><input autofocus required type="number" class="form-control"
                                                        name="jumlah">
                                                </td>
                                                <td><input autofocus required type="text" class="form-control"
                                                        name="ket">
                                                </td>
                                                <td><input autofocus required type="date" class="form-control"
                                                        name="expired">
                                                </td>
                                                <td></td>
                                                <td><button type="submit" class="btn btn-primary btn-sm">Simpan</button>
                                                </td>
                                            </form>
                                        </tr>
                                        <?php
                                            $no =1;
                                        ?>
                                        <?php $__currentLoopData = $voucher; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td align='center'><?php echo e($no++); ?></td>
                                                <td><?php echo e($k->kode); ?></td>
                                                <td><?php echo e(number_format($k->jumlah,0)); ?></td>
                                                <td><?php echo e($k->ket); ?></td>
                                                <td><?php echo e($k->expired); ?></td>
                                                <?php if($k->status == '1'){ ?>
                                                    <td align="center">
                                                    <a href="<?php echo e(route('setVoucher')); ?>?id=<?php echo e($k->id_voucher); ?>&status=0" class="btn btn-success"
                                                        >ON</a>
                                                    </td>
                                                    <?php }else{ ?>
                                                    <td align="center">
                                                    <a href="<?php echo e(route('setVoucher')); ?>?id=<?php echo e($k->id_voucher); ?>&status=1" class="btn btn-primary"
                                                        >OFF</a>
                                                    </td>
                                                    <?php } ?>
                                               
                                                <td align="right ">
                                                    
                                                    <a onclick="return confirm('Apakah ingin dihapus ?')"
                                                        href="<?php echo e(route('hapusVoucher', ['id_voucher' => $k->id_voucher])); ?>"
                                                        class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
            <!--/. container-fluid -->
        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->

    
    
    

    <!-- Control Sidebar -->
    <aside class="control-sidebar control-sidebar-dark">
        <!-- Control sidebar content goes here -->
    </aside>
    <!-- /.control-sidebar -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        <?php if(Session::get('sukses')) { ?>
        Swal.fire({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000,
            icon: 'success',
            title: "<?php echo e(Session::get('sukses')); ?>"
        });
        <?php }elseif(Session::get('error')) { ?>
        Swal.fire({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000,
            icon: 'error',
            title: "<?php echo e(Session::get('error')); ?>"
        });
        <?php } ?>
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\admin_upperclass\resources\views/voucher/voucher.blade.php ENDPATH**/ ?>