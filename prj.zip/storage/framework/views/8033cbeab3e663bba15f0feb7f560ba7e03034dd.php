
<?php $__env->startSection('content'); ?>
    <style>
        .modal-lg-max {
            max-width: 800px;
        }
        .modal-mds {
            max-width: 700px;
        }

    </style>
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">Product</h1>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item active">Product</li>
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->

        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header p-0 pt-1">
                                <ul class="nav nav-tabs" id="custom-tabs-two-tab" role="tablist">
                                    <?php $__currentLoopData = $lokasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="nav-item">
                                            <a class="nav-link <?php echo e($id_lokasi == $l->id_lokasi ? 'active' : ''); ?>"
                                                href="?id_lokasi=<?php echo e($l->id_lokasi); ?>"><?php echo e($l->nm_lokasi); ?></a>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                            <div class="card-body">
                                <a href="#" data-target="#tambah" data-toggle="modal" class="btn btn-primary btn-sm"><i
                                        class="fas fa-plus"></i> Tambah Produk</a>
                                <a href="#" data-target="#import" data-toggle="modal" class="btn btn-primary btn-sm"><i
                                        class="fas fa-file-import"></i> Import</a>
                                        <!-- Example split danger button -->
                                

                                <table id="example2" class="table table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th>NO</th>
                                            <th>KATEGORI</th>
                                            <th>NAMA PRODUK</th>
                                            <th>LOKASI</th>
                                            <th>DISTRIBUSI / LINK</th>
                                            <th>Video Produk</th>
                                            <th>AKSI</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                            $no = 1;
                                        ?>
                                        <?php $__currentLoopData = $produk1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $video = DB::table('tb_video')
                                                    ->where('id_produk', $k->id_produk)
                                                    ->get();
                                            ?>
                                            <tr>
                                                <td width="10"><?php echo e($no++); ?></td>
                                                <td><?php echo e($k->nm_kategori); ?></td>
                                                <td><?php echo e($k->nm_produk); ?></td>
                                                <td><?php echo e($k->nm_lokasi); ?></td>
                                                <?php
                                                    $harga = DB::table('tb_harga')
                                                        ->select('tb_harga.*', 'tb_distribusi.*')
                                                        ->join('tb_distribusi', 'tb_harga.id_distribusi', '=', 'tb_distribusi.id_distribusi')
                                                        ->where('id_produk', $k->id_produk)
                                                        ->get();
                                                ?>
                                                <td style="white-space: nowrap;" align="center">
                                                    <?php $__currentLoopData = $harga; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php
                                                            if (Str::lower($h->nm_distribusi) == 'shopee') {
                                                                $icon = 'https://img.icons8.com/color/48/000000/shopee.png';
                                                            } elseif (Str::lower($h->nm_distribusi) == 'tokopedia') {
                                                                $icon = 'https://www.freepnglogos.com/uploads/logo-tokopedia-png/logo-tokopedia-15.png';
                                                            }
                                                            $w = 40;
                                                        ?>
                                                        <img class="tes" src="<?php echo e($icon); ?>"
                                                            width="<?php echo e($w); ?>" />
                                                        : <a href="<?php echo e($h->link); ?>" target="blank"><button
                                                                class="btn btn-primary btn-sm">Go</button></a><br>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <button data-target="#tbhDistribusi<?php echo e($k->id_produk); ?>"
                                                        data-toggle="modal" class="btn btn-light btn-sm float-right"><i
                                                            class="fa fa-plus"></i></button>
                                                </td>
                                                <td>
                                                    <?php $__currentLoopData = $video; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <a href="<?php echo e($v->link_video); ?>"
                                                            target="blank"><?php echo e($v->link_video); ?></a>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </td>
                                                <td align="center">
                                                    <a href="#" data-toggle="modal"
                                                        data-target="#edit<?php echo e($k->id_produk); ?>"
                                                        class="btn btn-warning btn-sm"><i class="fa fa-edit"></i></a>
                                                    <a onclick="return confirm('Apakah anda yakin ?')"
                                                        href="<?php echo e(route('hapusProduk', ['id' => $k->id_produk, 'id_lokasi' => $id_lokasi])); ?>"
                                                        class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
            <!--/. container-fluid -->
        </section>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
    
    <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <form action="<?php echo e(route('tbhDistribusi')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="modal fade" id="tbhDistribusi<?php echo e($k->id_produk); ?>" role="dialog"
                aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-sm" role="document">
                    <div class="modal-content ">
                        <div class="modal-header btn-costume">
                            <h5 class="modal-title text-dark" id="exampleModalLabel">Tambah Distribusi</h5>
                            <button type="button" class="close text-dark" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <input type="hidden" name="id_produk" value="<?php echo e($k->id_produk); ?>">
                        <div class="modal-body">
                            <div class="row">
                                <div class="col-lg-12">
                                    <label for="">Distribusi</label>
                                    <select name="id_distribusi" class="form-control" id="">
                                        <option value="">- Pilih Distribusi -</option>
                                        <?php $__currentLoopData = $distribusi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($d->id_distribusi); ?>"><?php echo e($d->nm_distribusi); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-12">
                                    <label for="">Harga</label>
                                    <input class="form-control" type="number" name="harga">
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-lg-12">
                                    <label for="">Link</label>
                                    <input class="form-control" type="link" name="link">
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">

                            <button type="submit" class="btn btn-success">Edit / Save</button>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    
    <form action="<?php echo e(route('importProduk')); ?>" enctype="multipart/form-data" method="post">
        <?php echo csrf_field(); ?>
        <div class="modal fade" id="import" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-mds" role="document">
                <div class="modal-content ">
                    <div class="modal-header btn-costume">
                        <h5 class="modal-title text-dark" id="exampleModalLabel">Import Produk</h5>
                        <button type="button" class="close text-dark" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <table>
                                <tr>
                                <td width="100" class="pl-2">
                                    <img width="80px" src="<?php echo e(asset('assets')); ?>/img/1.png" alt="">
                                </td>
                                <td>
                                    <span style="font-size: 20px;"><b> Download Excel template</b></span><br>
                                    File ini memiliki kolom header dan isi yang sesuai dengan data produk
                                </td>
                                <td>
                                    <a href="<?php echo e(route('exportFormat')); ?>" class="btn btn-primary btn-sm"><i class="fa fa-download"></i> DOWNLOAD TEMPLATE</a>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="3">
                                    <hr>
                                </td>
                            </tr>
                            <tr>
                                <td width="100" class="pl-2">
                                    <img width="80px" src="<?php echo e(asset('assets')); ?>/img/2.png" alt="">
                                </td>
                                <td>
                                    <span style="font-size: 20px;"><b> Upload Excel template</b></span><br>
                                    Setelah mengubah, silahkan upload file.
                                </td>
                                <td>
                                    <input type="file" name="file" class="form-control">
                                </td>
                            </tr>
                            </table>
                            
                        </div>
                        <div class="row">
                            <div class="col-12">
                                
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-success">Edit / Save</button>
                    </div>
                </div>
            </div>
        </div>
    </form>
    
    
    
    <form action="<?php echo e(route('tambahProduk')); ?>" enctype="multipart/form-data" method="post">
        <?php echo csrf_field(); ?>
        <div class="modal fade" id="tambah" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content ">
                    <div class="modal-header btn-costume">
                        <h5 class="modal-title text-dark" id="exampleModalLabel">Tambah Produk</h5>
                        <button type="button" class="close text-dark" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <input type="hidden" name="id_lokasi" value="<?php echo e($id_lokasi); ?>">
                            <div class="col-md-3">
                                <label for="" class="form-label">Kategori</label>
                                <select class="form-control" name="id_kategori" id="tbh">
                                    <option value="">- Pilih Kategori -</option>
                                    
                                    <div id="katego"></div>
                                    <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($k->id_kategori); ?>"><?php echo e($k->nm_kategori); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                    
                                </select>
                            </div>
                            <div class="col-md-1">
                                <label for="">Aksi</label>
                                <a href="#" data-target="#tbhKategori" class="btn btn-success btn-sm" data-toggle="modal"><i class="fa fa-plus"></i></a>
                            </div>
                            <div class="col-md-4">
                                <label for="formFile">Foto</label>
                                <input class="form-control" type="file" name="foto" id="formFile">
                            </div>
                            <div class="col-md-4">
                                <label for="">Satuan</label>
                                <select class="form-control" name="id_satuan" id="">
                                    <option value="">- Pilih Satuan -</option>
                                    <?php $__currentLoopData = $satuan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($k->id_satuan); ?>"><?php echo e($k->nm_satuan); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label for="">Nama Produk</label>
                                <input type="text" class="form-control" name="nm_produk">
                            </div>
                            <div class="col-md-4">
                                <label for="">Harga Modal</label>
                                <input type="number" class="form-control" name="harga_modal">
                            </div>
                            <div class="col-md-4">
                                <label for="">Produk Video</label>
                                <input type="url" class="form-control" name="link_video">
                            </div>
                        </div>


                        <div class="row">

                            <div class="col-md-12">
                                <label for="">Deskripsi</label>
                                <textarea class="ckeditor" id="ckedtor" name="deskripsi"></textarea>
                                
                            </div>
                            

                        </div><br>
                        <div class="row">
                            <div class="col-3">
                                <label for="">Distribusi</label>
                                <select name="id_distribusi[]" class="form-control" id="">
                                    <option value="">- Pilih Distribusi -</option>
                                    <?php $__currentLoopData = $distribusi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($d->id_distribusi); ?>"><?php echo e($d->nm_distribusi); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-3">
                                <label for="">Link</label>
                                <input type="url" class="form-control" name="link[]">
                            </div>
                            <div class="col-3">
                                <label for="">Harga</label>
                                <input type="number" class="form-control" name="harga[]">
                            </div>
                            <div class="col-1">
                                <label for="">Aksi</label>
                                <a href="#" class="btn btn-success btn-sm" id="tambah_distribusi"><i
                                        class="fa fa-plus"></i></a>
                            </div>
                        </div>

                        <div id="add_distribusi">

                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-success">Edit / Save</button>
                    </div>
                </div>
            </div>
        </div>
    </form>
    

    
    
    <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <form action="<?php echo e(route('ubahProduk')); ?>" enctype="multipart/form-data" method="post">

            <?php echo csrf_field(); ?>
            <div class="modal fade" id="edit<?php echo e($s->id_produk); ?>" role="dialog" aria-labelledby="exampleModalLabel"
                aria-hidden="true">
                <div class="modal-dialog modal-lg" role="document">
                    <div class="modal-content ">
                        <div class="modal-header btn-costume">
                            <h5 class="modal-title text-dark" id="exampleModalLabel">Edit Produk</h5>
                            <button type="button" class="close text-dark" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <input type="hidden" name="id_produk" value="<?php echo e($s->id_produk); ?>">
                            <input type="hidden" name="id_lokasi" value="<?php echo e($id_lokasi); ?>">
                            <div class="row">
                                <div class="col-6">
                                    <img width="100%"
                                        src="<?php echo e(asset('assets')); ?>/uploads/<?php echo e($s->foto == '' ? 'noimage.jpg' : $s->foto); ?>"
                                        alt="">
                                    <div class="row">

                                        <div class="col-12">
                                            <input type="file" name="foto" class="form-control">
                                        </div>
                                    </div>
                                    <?php
                                        $video = DB::table('tb_video')
                                            ->where('id_produk', $s->id_produk)
                                            ->get();
                                        
                                    ?>
                                    <label class="mt-2" for="">Product Video</label>
                                    <?php $__currentLoopData = $video; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="row">
                                            <div class="col-10">
                                                
                                                <input type="url" name="link_video[]" class="form-control"
                                                    value="<?php echo e($v->link_video); ?>">
                                            </div>
                                            <div class="col-2">
                                                <a href="<?php echo e(route('hapusLinkV', ['id' => $v->id_video])); ?>"
                                                    class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></a>
                                            </div>
                                        </div>
                                        <input type="hidden" name="id_video[]" value="<?php echo e($v->id_video); ?>">
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <input type="text" name="link_v_i" class="form-control">

                                </div>
                                <div class="col-6">
                                    <div class="row mb-3 mb-3">
                                        <div class="col-6">
                                            <label for="" class="form-label">Kategori</label>
                                            <select class="form-control" name="id_kategori" id="">
                                                <option value="">- Pilih Kategori -</option>
                                                <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option <?php echo e($s->id_kategori == $k->id_kategori ? 'selected' : ''); ?>

                                                        value="<?php echo e($k->id_kategori); ?>"><?php echo e($k->nm_kategori); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="col-6">
                                            <label for="">Satuan</label>
                                            <select class="form-control" name="id_satuan" id="">
                                                <option value="">- Pilih Satuan -</option>
                                                <?php $__currentLoopData = $satuan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option <?php echo e($s->id_satuan == $k->id_satuan ? 'selected' : ''); ?>

                                                        value="<?php echo e($k->id_satuan); ?>"><?php echo e($k->nm_satuan); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <div class="col-12">
                                            <label for="">Nama Produk</label>
                                            <input type="text" value="<?php echo e($s->nm_produk); ?>" class="form-control"
                                                name="nm_produk">
                                        </div>
                                    </div>
                                    <div class="row mb-3">
                                        <div class="col-12">
                                            <textarea class="ckeditor" id="ckedtor" name="deskripsi"><?php echo e($s->deskripsi); ?></textarea>
                                        </div>
                                    </div>
                                    <?php
                                        $harga = DB::table('tb_harga')
                                            ->select('tb_harga.*', 'tb_distribusi.*')
                                            ->join('tb_distribusi', 'tb_harga.id_distribusi', '=', 'tb_distribusi.id_distribusi')
                                            ->where('id_produk', $s->id_produk)
                                            ->get();
                                    ?>
                                    <?php $__currentLoopData = $harga; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="hidden" name="id_distribusi[]" value="<?php echo e($h->id_distribusi); ?>">
                                    <input type="hidden" name="id_harga[]" value="<?php echo e($h->id_harga); ?>">
                                        <?php
                                            if (Str::lower($h->nm_distribusi) == 'shopee') {
                                                $icon = 'https://img.icons8.com/color/48/000000/shopee.png';
                                            } elseif (Str::lower($h->nm_distribusi) == 'tokopedia') {
                                                $icon = 'https://www.freepnglogos.com/uploads/logo-tokopedia-png/logo-tokopedia-15.png';
                                            }
                                            $w = 48;
                                        ?>
                                        <div class="row">
                                            <div class="col-2"></div>
                                            <div class="col-10">
                                                <label for="">Harga</label>
                                                <input class="form-control" type="number" name="harga[]"
                                                    value="<?php echo e($h->harga); ?>">
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-2">
                                                <img class="tes" src="<?php echo e($icon); ?>"
                                                    width="<?php echo e($w); ?>" />
                                            </div>
                                            <div class="col-10">
                                                <input class="form-control" type="text" name="link[]"
                                                    value="<?php echo e($h->link); ?>">
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                            

                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-success">Edit / Save</button>
                        </div>
                    </div>
                </div>
            </div>
        </form>
        <div class="modal fade" id="modalDropzone<?php echo e($s->id_produk); ?>" role="dialog"
            aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content ">
                    <div class="modal-header btn-costume">
                        <h5 class="modal-title text-dark" id="exampleModalLabel">Upload Images</h5>
                        <button type="button" class="close text-dark" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>

                    <div class="modal-body">
                        <form action="<?php echo e(route('uploadImages', ['id_produk' => $s->id_produk])); ?>"
                            class="dropzone" method="get" enctype="multipart/form-data">

                            <?php echo e(csrf_field()); ?>


                        </form>
                    </div>
                    <div class="modal-footer">

                        <button type="submit" class="btn btn-success">Edit / Save</button>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
     
       
     <form method="post" action="<?php echo e(route('tbhKategoriProduk')); ?>">
        <?php echo csrf_field(); ?>
        <div class="modal fade" id="tbhKategori" role="dialog"
            aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-sm" role="document">
                <div class="modal-content ">
                    <div class="modal-header btn-costume">
                        <h5 class="modal-title text-dark" id="exampleModalLabel">Tambah Kategori</h5>
                        <button type="button" class="close text-dark" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <input type="hidden" name="id_lokasi" value="<?php echo e($id_lokasi); ?>" id="id_lokasi">
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-lg-12">
                                <label for="">Nama Kategori</label>
                                <input autofocus class="form-control" type="text"
                                    name="nm_kategori">
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">

                        <button type="submit" class="btn btn-success">Edit / Save</button>
                    </div>
                </div>
            </div>
        </div>
    </form>
    <!-- Control Sidebar -->
    <aside class="control-sidebar control-sidebar-dark">
        <!-- Control sidebar content goes here -->
    </aside>
    <!-- /.control-sidebar -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        <?php if(Session::get('sukses')) { ?>
        Swal.fire({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000,
            icon: 'success',
            title: "<?php echo e(Session::get('sukses')); ?>"
        });
        <?php }elseif(Session::get('error')) { ?>
        Swal.fire({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000,
            icon: 'error',
            title: "<?php echo e(Session::get('error')); ?>"
        });
        <?php } ?>
        $(document).ready(function() {
            $(document).on('click', '.tes', function() {
                alert(1)
            })
            var jml = 1;
            $('#tambah_distribusi').click(function() {
                jml += 1
                var html = "<div class='row mt-3' id='row_stk" + jml + "'>"
                html +=
                    '<div class="col-3"><select name="id_distribusi[]" class="form-control" id=""><option value="">- Pilih Distribusi -</option><?php $__currentLoopData = $distribusi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($d->id_distribusi); ?>"><?php echo e($d->nm_distribusi); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div > '
                html +=
                    '<div class="col-3"><input type="url" class="form-control" name="link[]"></div>'
                html +=
                    '<div class="col-3"><input type="number" class="form-control" name="harga[]"></div>'
                html +=
                    '<div class="col-1"><a href="#" class="btn btn-danger btn-sm remove_stk" data-row="row_stk' +jml + '"><i class="fa fa-minus"></i></a></div>'
                html += '</div>'
                $('#add_distribusi').append(html);
                $('.select').select2()
            })

            $(document).on('click', '.remove_stk', function() {
                var delete_row = $(this).data("row");
                $('#' + delete_row).remove();
            });

            $('.modal').on('hidden.bs.modal', function () {
            //If there are any visible
            if($(".modal:visible").length > 0) {
                //Slap the class on it (wait a moment for things to settle)
                setTimeout(function() {
                    $('body').addClass('modal-open');
                },200)
            }

            // $(document).on('submit', '#formtbhKategori', function(){
            //     event.preventDefault();
            //     var id_lokasi = $('#id_lokasi').val()
            //     var kategori = $('#tbhKategori').serialize()
                
            //     $.ajax({
            //         type: "GET",
            //         url: "<?php echo e(route('tbhKategoriProduk')); ?>?aksi=1&"+kategori,
            //         contentType: false,
            //         processData: false,
            //         success: function (response) {
            //             Swal.fire({
            //             toast: true,
            //             position: 'top-end',
            //             showConfirmButton: false,
            //             timer: 3000,
            //             icon: 'success',
            //             title: 'Post center berhasil dibuat'
            //             });
            //         }
            //     });
            // })
        });

        })

        
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\admin_upperclass\resources\views/product/product.blade.php ENDPATH**/ ?>