<!-- Main Sidebar Container -->
<aside class="main-sidebar elevation-4">
    <!-- Brand Logo -->
    <a href="index3.html" class="brand-link">
        <img src="<?php echo e(asset('assets')); ?>/dist/img/logoup.png" alt="AdminLTE Logo"
            class="brand-image image-center elevation-3" style="opacity: .8">
        <p class="text-block text-info text-md">Admin Upperclass</p>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">

        <!-- Sidebar Menu -->
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                <li class="nav-item">
                    <a href="<?php echo e(route('dashboard')); ?>"
                        class="nav-link <?php echo e(request()->is('dashboard') ? 'active' : ''); ?>">
                        <i class="
                        nav-icon fas fa-tachometer-alt"></i>
                        <p>Dashboard</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('produk')); ?>" class="nav-link <?php echo e(request()->is('produk') ? 'active' : ''); ?>">
                        <i class="nav-icon fas fa-store"></i>
                        <p>Product</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="#" class="nav-link">
                        <i class="nav-icon fas fa-chart-pie"></i>
                        <p>
                            Database
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview" style="display: none;">
                        <li class="nav-item">
                            <a href="<?php echo e(route('banner')); ?>"
                                class="nav-link <?php echo e(request()->is('banner') ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Banner</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('bestSeller')); ?>"
                                class="nav-link <?php echo e(request()->is('bestSeller') ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Best Seller / Top Rate</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('about')); ?>"
                                class="nav-link <?php echo e(request()->is('about') ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>About Us</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('footer')); ?>"
                                class="nav-link <?php echo e(request()->is('footer') ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Footer Info</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('lokasi')); ?>"
                                class="nav-link <?php echo e(request()->is('lokasi') ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Lokasi</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('kategori')); ?>"
                                class="nav-link <?php echo e(request()->is('kategori') ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Kategori</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('satuan')); ?>"
                                class="nav-link <?php echo e(request()->is('satuan') ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Satuan</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('distribusi')); ?>"
                                class="nav-link <?php echo e(request()->is('distribusi') ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Distribusi</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('user')); ?>"
                                class="nav-link <?php echo e(request()->is('user') ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>User</p>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </nav>
        <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
</aside>
<?php /**PATH C:\Users\User\Desktop\admin_upperclass\resources\views/template/sidebar.blade.php ENDPATH**/ ?>